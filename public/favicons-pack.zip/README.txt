# Favicons for Manga Pro Reader

Place **all files** in this zip into your project's `public/` folder.

Then add the following tags inside `<head>` of your `index.html`:

<link rel="icon" type="image/png" sizes="32x32" href="/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="16x16" href="/favicon-16x16.png">
<link rel="apple-touch-icon" sizes="180x180" href="/apple-touch-icon.png">
<link rel="manifest" href="/site.webmanifest">
<link rel="icon" href="/favicon.ico">
<meta name="theme-color" content="#111111">


Optionally set the title:
<title>Mangaku — Manga Pro Reader</title>
